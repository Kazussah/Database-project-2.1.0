CREATE DATABASE home_service; 

USE home_service;
-- 2. Users table (both customers & service providers)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20),
    role ENUM('customer', 'provider', 'admin') DEFAULT 'customer',
    profile_picture VARCHAR(255),
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Service categories
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT
);

-- 4. Services
CREATE TABLE services (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    provider_id INT NOT NULL,
    category_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    availability ENUM('available', 'unavailable') DEFAULT 'available',
    FOREIGN KEY (provider_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE
);

-- 5. Bookings
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    service_id INT NOT NULL,
    booking_date DATE NOT NULL,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
    total_amount DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

-- 6. Reviews
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- 7. Payments
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('credit_card', 'mobile_money', 'cash') NOT NULL,
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);
INSERT INTO users (full_name, email, password_hash, phone_number, role)
VALUES
('John Doe', 'john@example.com', 'hashedpassword123', '1234567890', 'customer'),
('Sarah Smith', 'sarah@example.com', 'hashedpassword456', '0987654321', 'provider'),
('Mike Johnson', 'mike@example.com', 'hashedpassword789', '1122334455', 'provider'),
('Admin User', 'admin@example.com', 'hashedpassword999', '0000000000', 'admin');

-- Categories
INSERT INTO categories (category_name, description)
VALUES
('Plumbing', 'All plumbing repair and installation services'),
('Cleaning', 'House, office, and industrial cleaning services'),
('Electrical', 'Electrical wiring, repair, and installation');

-- Services
INSERT INTO services (provider_id, category_id, title, description, price, availability)
VALUES
(2, 1, 'Fix leaking pipe', 'Repair leaking kitchen or bathroom pipes', 50.00, 'available'),
(2, 2, 'Deep house cleaning', 'Full cleaning of house including carpets and windows', 120.00, 'available'),
(3, 3, 'Electrical wiring installation', 'Full house wiring setup', 300.00, 'available');

-- Bookings
INSERT INTO bookings (customer_id, service_id, booking_date, status, total_amount)
VALUES
(1, 1, '2025-08-15', 'confirmed', 50.00),
(1, 2, '2025-08-18', 'pending', 120.00);

-- Reviews
INSERT INTO reviews (booking_id, rating, comment)
VALUES
(1, 5, 'Excellent service, quick and professional');

-- Payments
INSERT INTO payments (booking_id, amount, payment_method, payment_status)
VALUES
(1, 50.00, 'mobile_money', 'paid'),
(2, 120.00, 'cash', 'pending');